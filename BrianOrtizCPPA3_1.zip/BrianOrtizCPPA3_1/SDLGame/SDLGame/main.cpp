#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>

#include <iostream>
#include <stdio.h>
#include <string>

//bool to maintain prog loop
bool quit = false;

int main(int argc, char* argv[]) {

	SDL_Window* window; //decalre pointer

	//create a rendered variable
	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING); //Initialize SDL2

	//Create an application window with the following settings : 
	window = SDL_CreateWindow(
		"Space Game",			//Window title
		SDL_WINDOWPOS_UNDEFINED,		//initial x position
		SDL_WINDOWPOS_UNDEFINED,		//initial y pos
		1024,			//width, in pixel
		768,		//height  in pixel
		SDL_WINDOW_OPENGL		//flags - see below
	);

	//Check that the window was successfully created
	if (window == NULL) {
		//in the case that the window could not be made
		printf("Could Not Create Window: %s\n", SDL_GetError());
		return 1;
	}

	//create rendered 
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//background image -- create


		//create a sdl surface
	SDL_Surface* surface;

	//attach background to surface
	surface = IMG_Load("./Assets/background.png");

	//create background textre;
	SDL_Texture* bkgd;

	//place surface into the texture
	bkgd = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//create rectangles for the menu graphics
	SDL_Rect bkgdPos;

	//set background pos x , y , width , and height
	bkgdPos.x = 0;
	bkgdPos.y = 0;
	bkgdPos.w = 1024;
	bkgdPos.h = 768;

	//BACKGROUND IMAGE -- CREATE END

		//PLAYER IMAGE -- START

		//create a sdl surface
	surface = IMG_Load("./Assets/player.png");

	//create background texture
	SDL_Texture* player;

	//place surface into the texture
	player = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//crete reactangles for the plaeur pos
	SDL_Rect playerPos;

	//set background x , y , width , and height
	playerPos.x = 400;
	playerPos.y = 700;
	playerPos.w = 180;
	playerPos.h = 54;


	//PLAYAER IMAGE -- CREATE END

	SDL_Event event;

	while (!quit) {

		//check for input
		if (SDL_PollEvent(&event)) {
			//close window by the windows x button
			if (event.type == SDL_QUIT) {
				quit = true;
			}
		}

		//DRAW +++++++++++++++++++++==

		//clear the ol dbuffer
		SDL_RenderClear(renderer);

		//preprare to draw backrground
		SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

		//prepare to draw player
		SDL_RenderCopy(renderer, player, NULL, &playerPos);

		//draww new infor to the screen 
		SDL_RenderPresent(renderer);

		//END DRAW )))))))))))))))))))))))

	}
	//close and destroy the window
	SDL_DestroyWindow(window);

	//clean up
	SDL_Quit();

	return 0;
};